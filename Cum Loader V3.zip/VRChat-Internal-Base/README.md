# VRChat-Internal-Base
A base for a VRChat internal using HexedLoader (EAC WORKING). 
You need HexedLoader to use this, without HexedLoader the code is useless!!!. 

Features are:
- Alt Key Zoom
- Player creation Hook
- A ready to use base to work with

Disclaimer: The provided code is just for educational purpose only. The provided code is a simple example on how to hook functions and use the implemented loader function.
