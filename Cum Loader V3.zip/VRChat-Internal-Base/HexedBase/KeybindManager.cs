﻿using UnityEngine;

namespace HexedBase
{
    internal class KeybindManager
    {
        public static void Update()
        {
            
        }
    }
}
