﻿using OVR.OpenVR;
using Starborn.API;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.InputSystem.LowLevel;

namespace HexedBase
{
    internal class Main
    {
        private bool isStraight = true;
        private bool isDetectorOn = false;
        private bool isDadFinderOn = false;
        private bool isHDetectorOn = false;
        private bool isNazi = false;
        private bool isGay = false;
        private bool areEardrumsBlownOut = false;
        public static VRCPage MainPage;
        public static ButtonGroup MainGrp;
        public static VRCPage SubMainPage;
        public static ButtonGroup SubGrp;
        public static void Init()
        {
            MainPage = new VRCPage("Cum Loader");
            new Tab(MainPage, "Cum Loader", clientResources.Icon());
            MainGrp = new ButtonGroup(MainPage, "Main", false);
            

            MainGrp.AddToggle("Boner", (isStraight) =>
            {
                if (isStraight)
                {
                    isStraight = false;
                    LogHandler.Log(LogHandler.Colors.White, "You just got Erect");
                    LogHandler.Log(LogHandler.Colors.White, "You watched gay porn");
                    LogHandler.Log(LogHandler.Colors.White, "I have a boner");
                }
                else
                {
                    isStraight = true;
                    LogHandler.Log(LogHandler.Colors.White, "You are now Flaccid");
                    LogHandler.Log(LogHandler.Colors.White, "(you watched straight porn)");
                    LogHandler.Log(LogHandler.Colors.White, "I have a small pp");
                }
            });

            MainGrp.AddButton("Click to cum!", "ambatakam", () =>
            {
                LogHandler.Log(LogHandler.Colors.White, "You Came");
            });

            MainGrp.AddToggle("E-Thot Detector", (isDetectorOn) =>
            {
                if (isDetectorOn)
                {
                    isDetectorOn = true;
                    LogHandler.Log(LogHandler.Colors.White, "E-Thot Detector - On");
                    LogHandler.Log(LogHandler.Colors.White, "Beep Beep Beep Beep");
                    LogHandler.Log(LogHandler.Colors.White, "E-Thot has been loctated!");
                    LogHandler.Log(LogHandler.Colors.White, "Calling All E-Thots!");
                }
                else
                {
                    isDetectorOn = false;
                    LogHandler.Log(LogHandler.Colors.White, "E-Thot Detector - Off");
                    LogHandler.Log(LogHandler.Colors.White, "No more pixel pounding for you.");
                    LogHandler.Log(LogHandler.Colors.White, "I get no bitches");
                }
            });

            MainGrp.AddButton("WC Staff ERP", "Lets you Erp With World Client Staff members!", () =>
            {
                LogHandler.Log(LogHandler.Colors.White, "You send out a signal to world client staff that you want to erp");
            });

            MainGrp.AddButton("Made By Cyconi and Pythol", "Cyconi is Best World Client Staff", () =>
            {
                LogHandler.Log(LogHandler.Colors.White, "Cyconi is Hot");
                LogHandler.Log(LogHandler.Colors.White, "Pythol is lowkey kinda cute");
            });

            MainGrp.AddToggle("Dad Finder", (isDadFinderOn) =>
            {
                if (isDadFinderOn)
                {
                    isDadFinderOn = true;
                    LogHandler.Log(LogHandler.Colors.White, "Dad Finder - On");
                    LogHandler.Log(LogHandler.Colors.White, "Beep Beep Beep Beep");
                    LogHandler.Log(LogHandler.Colors.White, "This may take some time...");
                    LogHandler.Log(LogHandler.Colors.White, "Looking for a father figure!");
                    Process.Start("https://dadfinder9000.site123.me/");
                }
                else
                {
                    isDadFinderOn = false;
                    LogHandler.Log(LogHandler.Colors.White, "Dad Finder - Off");
                    LogHandler.Log(LogHandler.Colors.White, "We were unable to find your dad");
                    LogHandler.Log(LogHandler.Colors.White, "No longer looking for a father figure");
                }
            });

            MainGrp.AddToggle("Horny Detector", (isHDetectorOn) =>
            {
                if (isHDetectorOn)
                {
                    isHDetectorOn = true;
                    LogHandler.Log(LogHandler.Colors.White, "Horny Detector - On");
                    LogHandler.Log(LogHandler.Colors.White, "Beep Beep Beep Beep");
                    LogHandler.Log(LogHandler.Colors.White, "You are horny!");
                    Process.Start("https://youtu.be/oO-gc3Lh-oI");
                }
                else
                {
                    isHDetectorOn = false;
                    LogHandler.Log(LogHandler.Colors.White, "Horny Detector - Off");
                    LogHandler.Log(LogHandler.Colors.White, "We couldn't find the Horny");
                }
            });
            //Making the new sub menu and its contents
            SubMainPage = new VRCPage("Submissive Menu");
            SubGrp = new ButtonGroup(SubMainPage, "", false);

            SubGrp.AddButton("Clean up", "Click to Cum!", () =>
            {
                LogHandler.Log(LogHandler.Colors.White, "You cleaned up all the Cum!");
            });

            SubGrp.AddToggle("Apiss Swastika", (isNazi) =>
            {
                if (isNazi)
                {
                    isNazi = true;
                    LogHandler.Log(LogHandler.Colors.White, "waaaaa someone is using my skidded orbit");
                    LogHandler.Log(LogHandler.Colors.White, "goo goo gaa gaa, i got mad someone made a joke about my orbit");
                }
                else
                {
                    isNazi = false;
                    LogHandler.Log(LogHandler.Colors.White, "bunny pissing there pants rn");
                    LogHandler.Log(LogHandler.Colors.White, "Fuck apiss lmaoo");
                }
            });

            SubGrp.AddButton("Cum Zone", "Play cum zone", () =>
            {
                Process.Start("https://youtu.be/j0lN0w5HVT8");
            });

            SubGrp.AddButton("Subway Sexists", "Subway Sexists", () =>
            {
                Process.Start("https://youtu.be/uFPu4Gfau2o");
            });

            SubGrp.AddButton("Cum?", "Cum whats that?", () =>
            {
                for (int i = 0; i < 10; i++)
                {
                    Process.Start("https://www.urbandictionary.com/define.php?term=Cum");
                }
            });

            SubGrp.AddButton("Hentai", "mmmm Hentai", () =>
            {
                Process.Start("https://nhentai.net/");
                Process.Start("https://hanime.tv/");
            });

            SubGrp.AddToggle("Gay", (isGay) =>
            {
                if (isGay)
                {
                    isGay = true;
                    LogHandler.Log(LogHandler.Colors.White, "You are gay, very gay");
                    Process.Start("https://youtu.be/dQw4w9WgXcQ");
                }
                else
                {
                    isGay = false;
                    LogHandler.Log(LogHandler.Colors.White, "you have ungayed");
                }
            });

            SubGrp.AddButton("Fatherless Child", "Toggle Fatherless Child Detector", () =>
            {
                LogHandler.Log(LogHandler.Colors.White, "Fatherless Child Detector - On");
                LogHandler.Log(LogHandler.Colors.White, "Beep Beep Beep Beep");
                LogHandler.Log(LogHandler.Colors.White, "Fatherless Child been loctated!");
                Process.Start("https://youtu.be/vA_P0IPNcog");
            });

            SubGrp.AddButton("HES PULLING HIS COCK OUT", "HES PULLING HIS COCK OUT!!", () =>
            {
                Process.Start("https://youtu.be/YwILuJ5lVwM");
                LogHandler.Log(LogHandler.Colors.White, "HES PULLING HIS COCK OUT!!");
            });

            SubGrp.AddButton("Men", "Men", () =>
            {
                Process.Start("https://youtu.be/YwILuJ5lVwM");
                for (int i = 0; i < 50; i++)
                {
                    LogHandler.Log(LogHandler.Colors.White, "Men");
                }
            });

            SubGrp.AddToggle("gahhhhhhhhhhhhhhhhhhhhhhhh myyyyyyy earrrrrrrrrrrrrrssss", (areEardrumsBlownOut) =>
            {
                if (areEardrumsBlownOut)
                {
                    areEardrumsBlownOut = true;
                    LogHandler.Log(LogHandler.Colors.White, "aasdjhlkfahsjklfhasjlkdf hajklsdhfjklashdfjkahfjlashdjfkghaejofhsanbcjkvahbdjkglhadjklvhajksfhasdkjlfha ");
                }
                else
                {
                    areEardrumsBlownOut = false;
                    LogHandler.Log(LogHandler.Colors.White, "my ears hurt...");
                }
            });

            //Finishing off with the last few Main buttons

            MainGrp.AddButton("Sub Menu", "Opens the submissive menu OwO", () =>
            {
                SubMainPage.OpenMenu();
            });

            new VRCSlider(MainPage, "Cum Strength", "How hard will you cum", (cumStr) =>
            {
                LogHandler.Log(LogHandler.Colors.White, "Cum Strength Adjusted To " + cumStr + "%");
            }, 25f, 0f, 100f);
        }
    }
}
